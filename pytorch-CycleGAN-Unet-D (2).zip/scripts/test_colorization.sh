set -ex
python test.py --dataroot ./datasets/colorization --name color_pix2pix --model colorization
